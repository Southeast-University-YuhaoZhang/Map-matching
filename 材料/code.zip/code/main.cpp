#include "hmm_map_matching.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <algorithm>
#include <regex>
#include <cctype>
#include <iomanip>

struct TruthData {
    std::string trip;
    std::vector<std::string> real_road_ids;
    int start_idx;
    int end_idx;

    TruthData() : start_idx(0), end_idx(0) {}
};

std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> tokens;
    std::string token;
    bool in_quotes = false;

    for (size_t i = 0; i < line.length(); ++i) {
        char c = line[i];

        if (c == '"') {
            if (in_quotes && i + 1 < line.length() && line[i + 1] == '"') {
                token += '"';
                ++i;
            } else {
                in_quotes = !in_quotes;
            }
        } else if (c == ',' && !in_quotes) {
            tokens.push_back(token);
            token.clear();
        } else {
            token += c;
        }
    }
    tokens.push_back(token);
    return tokens;
}

std::vector<std::pair<double, double>> parse_linestring(const std::string& wkt) {
    std::vector<std::pair<double, double>> coords;

    size_t start_paren = wkt.find('(');
    size_t end_paren = wkt.find_last_of(')');

    if (start_paren == std::string::npos || end_paren == std::string::npos) {
        return coords;
    }

    std::string content = wkt.substr(start_paren + 1, end_paren - start_paren - 1);

    std::stringstream ss(content);
    std::string segment;

    while (std::getline(ss, segment, ',')) {
        segment.erase(0, segment.find_first_not_of(" \t\r\n"));
        segment.erase(segment.find_last_not_of(" \t\r\n") + 1);

        size_t space_pos = segment.find(' ');
        if (space_pos != std::string::npos) {
            try {
                double lon = std::stod(segment.substr(0, space_pos));
                double lat = std::stod(segment.substr(space_pos + 1));
                coords.emplace_back(lon, lat);
            } catch (...) {
                continue;
            }
        }
    }

    return coords;
}

bool try_read_file(std::ifstream& file, const std::string& filename, const std::string& encoding) {
    file.open(filename);
    return file.is_open();
}

std::vector<Edge> read_road_network(const std::string& filename) {
    std::vector<Edge> edges;
    std::ifstream file;

    if (!try_read_file(file, filename, "utf-8")) {
        std::cerr << "Failed to open road network file: " << filename << std::endl;
        return edges;
    }

    std::string line;
    std::getline(file, line);

    std::unordered_map<std::string, int> header_map;
    auto header_tokens = split_csv_line(line);
    for (size_t i = 0; i < header_tokens.size(); ++i) {
        std::string col_name = header_tokens[i];
        col_name.erase(col_name.find_last_not_of(" \t\r\n") + 1);
        col_name.erase(0, col_name.find_first_not_of(" \t\r\n"));
        header_map[col_name] = i;
    }

    int linkid_col = header_map.count("linkid") ? header_map["linkid"] : 1;
    int geometry_col = header_map.count("geometry_gcj02") ? header_map["geometry_gcj02"] : 
                       (header_map.count("geometry") ? header_map["geometry"] : 2);
    int oneway_col = header_map.count("oneway") ? header_map["oneway"] : 7;
    int maxspeed_col = header_map.count("maxspeed") ? header_map["maxspeed"] : 8;

    int line_number = 0;
    int skipped_linestring = 0;
    int skipped_coords = 0;
    int skipped_other = 0;

    while (std::getline(file, line)) {
        line_number++;
        if (line.empty()) continue;

        auto tokens = split_csv_line(line);
        
        if (tokens.size() <= std::max({linkid_col, geometry_col, oneway_col, maxspeed_col})) {
            std::cerr << "Line " << line_number << ": insufficient tokens (" << tokens.size() << "), skipping" << std::endl;
            continue;
        }

        std::string linkid = tokens[linkid_col];
        std::string geometry = tokens[geometry_col];

        if (geometry.empty() || geometry.find("LINESTRING") == std::string::npos) {
            skipped_linestring++;
            continue;
        }

        int oneway = 1;
        int maxspeed_kmh = 60;
        try {
            if (tokens.size() > oneway_col && !tokens[oneway_col].empty()) {
                oneway = std::stoi(tokens[oneway_col]);
            }
            if (tokens.size() > maxspeed_col && !tokens[maxspeed_col].empty()) {
                maxspeed_kmh = std::stoi(tokens[maxspeed_col]);
            }
        } catch (...) {
            skipped_other++;
        }

        double speed_limit = maxspeed_kmh / 3.6;
        bool two_way = (oneway == 0);

        auto coords = parse_linestring(geometry);
        if (coords.size() < 2) {
            skipped_coords++;
            continue;
        }

        std::string source, target;
        size_t underscore_pos = linkid.find('_');
        if (underscore_pos != std::string::npos) {
            source = linkid.substr(0, underscore_pos);
            // 处理 linkid 可能有多个下划线的情况
            size_t last_underscore = linkid.rfind('_');
            if (last_underscore != std::string::npos && last_underscore > underscore_pos) {
                target = linkid.substr(last_underscore + 1);
            } else {
                target = linkid.substr(underscore_pos + 1);
            }
        } else {
            std::ostringstream oss;
            oss.precision(6);
            oss << std::fixed << coords[0].first << "_" << coords[0].second;
            source = oss.str();
            oss.str("");
            oss << std::fixed << coords.back().first << "_" << coords.back().second;
            target = oss.str();
        }

        Edge edge(linkid, source, target, coords, speed_limit, two_way);
        edges.push_back(edge);
    }

    file.close();
    std::cout << "Loaded " << edges.size() << " road edges from " << filename << std::endl;
    std::cout << "  (skipped: " << skipped_linestring << " no LINESTRING, " << skipped_coords << " insufficient coords, " << skipped_other << " other errors)" << std::endl;
    return edges;
}

std::unordered_map<std::string, std::vector<Point>> read_gps_data(const std::string& filename) {
    std::unordered_map<std::string, std::vector<Point>> trajectories;
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open GPS data file: " << filename << std::endl;
        return trajectories;
    }

    std::string line;
    std::getline(file, line);

    while (std::getline(file, line)) {
        auto tokens = split_csv_line(line);
        if (tokens.size() < 6) continue;

        std::string trip_id = tokens[0];
        long long time = 0;
        double lat = 0.0;
        double lon = 0.0;

        try {
            time = std::stoll(tokens[2]);
            lat = std::stod(tokens[3]);
            lon = std::stod(tokens[4]);
        } catch (...) {
            continue;
        }

        trajectories[trip_id].emplace_back(lon, lat, time);
    }

    for (auto& kv : trajectories) {
        std::sort(kv.second.begin(), kv.second.end(),
                 [](const Point& a, const Point& b) { return a.timestamp < b.timestamp; });
    }

    file.close();
    std::cout << "Loaded " << trajectories.size() << " trajectories from " << filename << std::endl;
    return trajectories;
}

std::vector<std::string> split_by_dunhao(const std::string& str) {
    std::vector<std::string> result;
    
    // 使用正则表达式来匹配道路ID模式：数字_数字
    std::regex pattern(R"(\d+_\d+)");
    std::sregex_iterator it(str.begin(), str.end(), pattern);
    std::sregex_iterator end;
    
    for (std::sregex_iterator i = it; i != end; ++i) {
        std::smatch match = *i;
        result.push_back(match.str());
    }
    
    return result;
}

std::vector<TruthData> read_truth_data(const std::string& filename) {
    std::vector<TruthData> truth_list;
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open truth data file: " << filename << std::endl;
        return truth_list;
    }

    std::string line;
    std::getline(file, line);

    while (std::getline(file, line)) {
        auto tokens = split_csv_line(line);
        if (tokens.size() < 4) continue;

        TruthData truth;
        truth.trip = tokens[0];

        std::string real_str = tokens[1];
        std::vector<std::string> road_ids = split_by_dunhao(real_str);

        truth.real_road_ids = road_ids;

        try {
            truth.start_idx = std::stoi(tokens[2]);
            truth.end_idx = std::stoi(tokens[3]);
        } catch (...) {
            continue;
        }

        truth_list.push_back(truth);
    }

    file.close();
    std::cout << "Loaded " << truth_list.size() << " truth records from " << filename << std::endl;
    return truth_list;
}

void write_output(const std::string& filename,
                 const std::vector<std::tuple<std::string, std::vector<std::string>, double, double>>& results) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open output file: " << filename << std::endl;
        return;
    }

    file << "trip,road_ids,accuracy,computation_time(s)\n";

    for (const auto& result : results) {
        const std::string& trip = std::get<0>(result);
        const std::vector<std::string>& road_ids = std::get<1>(result);
        double accuracy = std::get<2>(result);
        double time = std::get<3>(result);

        file << trip << ",";

        for (size_t i = 0; i < road_ids.size(); ++i) {
            if (i > 0) file << "\xE3\x80\x81";
            file << road_ids[i];
        }

        file << "," << accuracy << "," << time << "\n";
    }

    file.close();
    std::cout << "Results written to: " << filename << std::endl;
}

struct MatchResult {
    std::string trip_id;
    std::vector<Point> trajectory;
    std::vector<Candidate> candidates;
    double accuracy;

    MatchResult(const std::string& id, const std::vector<Point>& traj, const std::vector<Candidate>& cands, double acc)
        : trip_id(id), trajectory(traj), candidates(cands), accuracy(acc) {}
};

void write_html_output(const std::string& filename,
                       const std::vector<MatchResult>& match_results,
                       const std::vector<Edge>& edges) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Failed to open HTML output file: " << filename << std::endl;
        return;
    }

    double min_lat = 999.0, max_lat = -999.0;
    double min_lon = 999.0, max_lon = -999.0;

    for (const auto& result : match_results) {
        for (const auto& point : result.trajectory) {
            min_lat = std::min(min_lat, point.lat);
            max_lat = std::max(max_lat, point.lat);
            min_lon = std::min(min_lon, point.lon);
            max_lon = std::max(max_lon, point.lon);
        }
        for (const auto& cand : result.candidates) {
            min_lat = std::min(min_lat, cand.point.lat);
            max_lat = std::max(max_lat, cand.point.lat);
            min_lon = std::min(min_lon, cand.point.lon);
            max_lon = std::max(max_lon, cand.point.lon);
        }
    }

    for (const auto& edge : edges) {
        for (const auto& coord : edge.coords) {
            min_lat = std::min(min_lat, coord.second);
            max_lat = std::max(max_lat, coord.second);
            min_lon = std::min(min_lon, coord.first);
            max_lon = std::max(max_lon, coord.first);
        }
    }

    double center_lat = (min_lat + max_lat) / 2.0;
    double center_lon = (min_lon + max_lon) / 2.0;

    file << "<!DOCTYPE html>\n";
    file << "<html>\n";
    file << "<head>\n";
    file << "    <meta charset=\"UTF-8\">\n";
    file << "    <title>HMM Map Matching Results</title>\n";
    file << "    <script src=\"https://unpkg.com/leaflet@1.7.1/dist/leaflet.js\"></script>\n";
    file << "    <link rel=\"stylesheet\" href=\"https://unpkg.com/leaflet@1.7.1/dist/leaflet.css\" />\n";
    file << "    <style>\n";
    file << "        body { margin: 0; padding: 0; }\n";
    file << "        #map { height: 100vh; width: 100%; background: #f0f0f0; }\n";
    file << "        .info-panel { position: fixed; top: 10px; left: 10px; background: white; padding: 15px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.15); font-family: Arial; font-size: 12px; max-width: 300px; z-index: 1000; }\n";
    file << "        .info-panel h3 { margin-top: 0; color: #333; }\n";
    file << "        .info-panel .trip-item { padding: 5px 0; border-bottom: 1px solid #eee; }\n";
    file << "        .info-panel .trip-item:last-child { border-bottom: none; }\n";
    file << "        .info-panel .trip-id { font-weight: bold; font-size: 11px; }\n";
    file << "        .info-panel .accuracy { color: #007bff; }\n";
    file << "    </style>\n";
    file << "</head>\n";
    file << "<body>\n";
    file << "    <div class=\"info-panel\">\n";
    file << "        <h3>Map Matching Results</h3>\n";

    file << std::fixed << std::setprecision(10);

    std::vector<std::string> colors = {"#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF",
                                      "#00FFFF", "#FFA500", "#800080", "#008000", "#000080"};

    for (size_t i = 0; i < match_results.size(); ++i) {
        const auto& result = match_results[i];
        std::string color = colors[i % colors.size()];
        file << "        <div class=\"trip-item\">\n";
        file << "            <div class=\"trip-id\" style=\"color: " << color << ";\">" << result.trip_id.substr(0, 8) << "...</div>\n";
        file << "            <div class=\"accuracy\">Accuracy: " << (result.accuracy * 100) << "%</div>\n";
        file << "        </div>\n";
    }

    file << "    </div>\n";
    file << "    <div id=\"map\"></div>\n";
    file << "    <script>\n";
    file << "        var map = L.map('map', {\n";
    file << "            center: [" << center_lat << ", " << center_lon << "],\n";
    file << "            zoom: 14,\n";
    file << "            layers: []\n";
    file << "        });\n";
    file << "\n";
    file << "        var roadNetworkLayer = L.layerGroup().addTo(map);\n";

    for (const auto& edge : edges) {
        file << "        L.polyline([";
        for (size_t j = 0; j < edge.coords.size(); ++j) {
            if (j > 0) file << ", ";
            file << "[" << edge.coords[j].second << ", " << edge.coords[j].first << "]";
        }
        file << "], {\n";
        file << "            color: '#cccccc',\n";
        file << "            weight: 2,\n";
        file << "            opacity: 0.6\n";
        file << "        }).bindPopup('Road: " << edge.id << "').addTo(roadNetworkLayer);\n";
    }

    file << "\n";
    file << "        var gpsLayer = L.layerGroup().addTo(map);\n";
    file << "        var pathLayer = L.layerGroup().addTo(map);\n";

    for (size_t i = 0; i < match_results.size(); ++i) {
        const auto& result = match_results[i];
        std::string color = colors[i % colors.size()];

        for (const auto& point : result.trajectory) {
            file << "        L.circleMarker([" << point.lat << ", " << point.lon << "], {\n";
            file << "            radius: 3,\n";
            file << "            fillColor: '" << color << "',\n";
            file << "            color: '#000',\n";
            file << "            weight: 1,\n";
            file << "            fillOpacity: 0.6\n";
            file << "        }).bindPopup('GPS: " << result.trip_id << "').addTo(gpsLayer);\n";
        }

        if (result.candidates.size() >= 2) {
            file << "        L.polyline([";
            for (size_t j = 0; j < result.candidates.size(); ++j) {
                if (j > 0) file << ", ";
                file << "[" << result.candidates[j].point.lat << ", " << result.candidates[j].point.lon << "]";
            }
            file << "], {\n";
            file << "            color: '" << color << "',\n";
            file << "            weight: 5,\n";
            file << "            opacity: 0.9\n";
            file << "        }).bindPopup('Matched: " << result.trip_id << "').addTo(pathLayer);\n";
        }
    }

    file << "\n";
    file << "        L.control.layers(null, {\n";
    file << "            'Road Network': roadNetworkLayer,\n";
    file << "            'GPS Points': gpsLayer,\n";
    file << "            'Matched Paths': pathLayer\n";
    file << "        }).addTo(map);\n";
    file << "    </script>\n";
    file << "</body>\n";
    file << "</html>\n";

    file.close();
    std::cout << "HTML visualization written to: " << filename << std::endl;
}

int main(int argc, char* argv[]) {
    std::cout << "HMM Map Matching - C++ Version" << std::endl;

    std::string input_dir = "..\\input\\";
    std::string output_dir = "..\\output\\";
    std::string road_file = input_dir + "road.csv";
    std::string gps_file = input_dir + "part_00001.csv";
    std::string truth_file = input_dir + "data.csv";
    std::string output_file = output_dir + "output.csv";
    bool use_prior = false;
    int prior_minutes = 0;

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--prior" && i + 1 < argc) {
            use_prior = true;
            prior_minutes = std::stoi(argv[++i]);
        } else if (arg == "--road" && i + 1 < argc) {
            road_file = argv[++i];
        } else if (arg == "--gps" && i + 1 < argc) {
            gps_file = argv[++i];
        } else if (arg == "--truth" && i + 1 < argc) {
            truth_file = argv[++i];
        } else if (arg == "--output" && i + 1 < argc) {
            output_file = argv[++i];
        }
    }

    std::cout << "Loading road network..." << std::endl;
    auto edges = read_road_network(road_file);

    std::cout << "Loading GPS data..." << std::endl;
    auto trajectories = read_gps_data(gps_file);

    std::cout << "Loading truth data..." << std::endl;
    auto truth_list = read_truth_data(truth_file);

    if (edges.empty()) {
        std::cerr << "Error: No road edges loaded. Exiting." << std::endl;
        return 1;
    }

    if (truth_list.empty()) {
        std::cerr << "Error: No truth data loaded. Exiting." << std::endl;
        return 1;
    }

    std::cout << "Initializing HMM map matching..." << std::endl;
    HMMMapMatching hmm(edges);

    std::vector<std::tuple<std::string, std::vector<std::string>, double, double>> results;
    std::vector<MatchResult> match_results;

    for (const auto& truth : truth_list) {
        auto it = trajectories.find(truth.trip);
        if (it == trajectories.end()) {
            std::cerr << "Trip not found: " << truth.trip << std::endl;
            continue;
        }

        const auto& full_trajectory = it->second;

        int start_idx = truth.start_idx - 1;
        int end_idx = truth.end_idx - 1;

        if (start_idx < 0 || end_idx < 0 ||
            start_idx >= static_cast<int>(full_trajectory.size()) ||
            end_idx >= static_cast<int>(full_trajectory.size()) ||
            start_idx > end_idx) {
            std::cerr << "Invalid start/end indices for trip: " << truth.trip << std::endl;
            continue;
        }

        std::vector<Point> main_trajectory;
        for (int i = start_idx; i <= end_idx; ++i) {
            main_trajectory.push_back(full_trajectory[i]);
        }

        std::vector<Point> prior_trajectory;
        if (use_prior && prior_minutes > 0) {
            long long prior_start_time = full_trajectory[start_idx].timestamp - prior_minutes * 60 * 1000LL;

            for (int i = 0; i < start_idx; ++i) {
                if (full_trajectory[i].timestamp >= prior_start_time) {
                    prior_trajectory.push_back(full_trajectory[i]);
                }
            }
            std::cout << "Using " << prior_trajectory.size() << " prior points for " << truth.trip << std::endl;
        }

        std::cout << "Processing trip: " << truth.trip << " (" << main_trajectory.size() << " points)" << std::endl;

        auto start_time = std::chrono::high_resolution_clock::now();
        auto candidates = hmm.match(
            main_trajectory,
            use_prior ? &prior_trajectory : nullptr,
            3, 50.0, 25.0
        );
        auto end_time = std::chrono::high_resolution_clock::now();
        double computation_time = std::chrono::duration<double>(end_time - start_time).count();
        
        auto timing = hmm.get_last_timing();
        
        std::unordered_set<std::string> truth_set(truth.real_road_ids.begin(), truth.real_road_ids.end());

        std::unordered_set<std::string> reversed_road_ids;
        for (const auto& road_id : truth.real_road_ids) {
            size_t first_underscore = road_id.find('_');
            if (first_underscore != std::string::npos) {
                size_t last_underscore = road_id.rfind('_');
                std::string reversed;
                if (first_underscore == last_underscore) {
                    reversed = road_id.substr(first_underscore + 1) + "_" + road_id.substr(0, first_underscore);
                } else {
                    std::string part1 = road_id.substr(0, first_underscore);
                    std::string part2 = road_id.substr(first_underscore + 1, last_underscore - first_underscore - 1);
                    std::string part3 = road_id.substr(last_underscore + 1);
                    reversed = part2 + "_" + part1 + "_" + part3;
                }
                reversed_road_ids.insert(reversed);
            }
        }
        truth_set.insert(reversed_road_ids.begin(), reversed_road_ids.end());

        int correct_count = 0;
        std::vector<std::string> matched_road_ids;

        for (const auto& cand : candidates) {
            std::string edge_id = cand.edge.id;
            size_t rev_pos = edge_id.rfind("_rev");
            std::string original_edge_id;
            
            if (rev_pos != std::string::npos && rev_pos == edge_id.length() - 4) {
                original_edge_id = edge_id.substr(0, rev_pos);
            } else {
                original_edge_id = edge_id;
            }
            
            matched_road_ids.push_back(original_edge_id);
            
            if (truth_set.count(original_edge_id) > 0) {
                correct_count++;
            } else {
                std::string reversed_edge_id;
                size_t first_underscore = original_edge_id.find('_');
                if (first_underscore != std::string::npos) {
                    size_t last_underscore = original_edge_id.rfind('_');
                    if (first_underscore == last_underscore) {
                        reversed_edge_id = original_edge_id.substr(first_underscore + 1) + "_" + original_edge_id.substr(0, first_underscore);
                    } else {
                        std::string part1 = original_edge_id.substr(0, first_underscore);
                        std::string part2 = original_edge_id.substr(first_underscore + 1, last_underscore - first_underscore - 1);
                        std::string part3 = original_edge_id.substr(last_underscore + 1);
                        reversed_edge_id = part2 + "_" + part1 + "_" + part3;
                    }
                }
                if (truth_set.count(reversed_edge_id) > 0) {
                    correct_count++;
                }
            }
        }

        double accuracy = candidates.empty() ? 0.0 : static_cast<double>(correct_count) / candidates.size();
        
        std::cout << "Trip " << truth.trip << ": accuracy = " << (accuracy * 100) << "%, time = " << computation_time << "s"
                  << " (cand=" << (timing.cand_gen * 1000) << "ms, viterbi=" << (timing.viterbi * 1000) << "ms)" << std::endl;

        results.emplace_back(truth.trip, matched_road_ids, accuracy, computation_time);
        match_results.emplace_back(truth.trip, main_trajectory, candidates, accuracy);
    }

    write_output(output_file, results);

    std::string html_output_file = output_file;
    size_t dot_pos = html_output_file.find_last_of('.');
    if (dot_pos != std::string::npos) {
        html_output_file = html_output_file.substr(0, dot_pos) + ".html";
    } else {
        html_output_file += ".html";
    }
    write_html_output(html_output_file, match_results, edges);

    double total_accuracy = 0.0;
    double total_time = 0.0;
    for (const auto& result : results) {
        total_accuracy += std::get<2>(result);
        total_time += std::get<3>(result);
    }

    if (!results.empty()) {
        std::cout << "\nOverall average accuracy: " << (total_accuracy / results.size() * 100) << "%" << std::endl;
        std::cout << "Total computation time: " << total_time << "s" << std::endl;
    }

    return 0;
}

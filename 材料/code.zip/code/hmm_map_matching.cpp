#include "hmm_map_matching.h"
#include <cmath>
#include <queue>
#include <algorithm>
#include <sstream>
#include <limits>

const double EARTH_RADIUS = 6371000.0;
const double LAT_INTERVAL = 0.0009;
const double LON_INTERVAL = 0.001337;

std::string create_node_id(double lon, double lat, int precision) {
    std::ostringstream oss;
    oss.precision(precision);
    oss << std::fixed << lon << "_" << lat;
    return oss.str();
}

inline double haversine_distance(const Point& p1, const Point& p2) {
    double lat1_rad = to_radians(p1.lat);
    double lon1_rad = to_radians(p1.lon);
    double lat2_rad = to_radians(p2.lat);
    double lon2_rad = to_radians(p2.lon);
    
    double dlat = lat2_rad - lat1_rad;
    double dlon = lon2_rad - lon1_rad;
    
    double sin_dlat_2 = std::sin(dlat * 0.5);
    double sin_dlon_2 = std::sin(dlon * 0.5);
    double cos_lat1 = std::cos(lat1_rad);
    double cos_lat2 = std::cos(lat2_rad);
    
    double a = sin_dlat_2 * sin_dlat_2 +
               cos_lat1 * cos_lat2 * sin_dlon_2 * sin_dlon_2;
    double c = 2.0 * std::atan2(std::sqrt(a), std::sqrt(1.0 - a));
    
    return EARTH_RADIUS * c;
}

inline double calculate_bearing(const Point& p1, const Point& p2) {
    double lat1_rad = to_radians(p1.lat);
    double lon1_rad = to_radians(p1.lon);
    double lat2_rad = to_radians(p2.lat);
    double lon2_rad = to_radians(p2.lon);
    
    double dlon = lon2_rad - lon1_rad;
    
    double y = std::sin(dlon) * std::cos(lat2_rad);
    double x = std::cos(lat1_rad) * std::sin(lat2_rad) -
               std::sin(lat1_rad) * std::cos(lat2_rad) * std::cos(dlon);
    
    return std::atan2(y, x);
}

PointToSegmentResult point_to_segment_distance(const Point& point,
                                               const std::pair<double, double>& seg_start,
                                               const std::pair<double, double>& seg_end) {
    PointToSegmentResult result;
    
    double px = point.lon - seg_start.first;
    double py = point.lat - seg_start.second;
    double dx = seg_end.first - seg_start.first;
    double dy = seg_end.second - seg_start.second;
    
    double dot = px * dx + py * dy;
    double len_sq = dx * dx + dy * dy;
    double t = (len_sq > 0) ? std::max(0.0, std::min(1.0, dot / len_sq)) : 0.0;
    
    double proj_lon = seg_start.first + t * dx;
    double proj_lat = seg_start.second + t * dy;
    Point proj_point(proj_lon, proj_lat);
    
    Point start_point(seg_start.first, seg_start.second);
    Point end_point(seg_end.first, seg_end.second);
    double seg_length = haversine_distance(start_point, end_point);
    double offset = t * seg_length;
    
    result.distance = haversine_distance(point, proj_point);
    result.proj_point = proj_point;
    result.offset = offset;
    
    return result;
}

Edge::Edge(const std::string& edge_id, const std::string& source, const std::string& target,
           const std::vector<std::pair<double, double>>& coords, double speed_limit, bool two_way)
    : id(edge_id), source(source), target(target), coords(coords),
      speed_limit(speed_limit), two_way(two_way) {
    
    if (coords.size() >= 2) {
        min_lon = max_lon = coords[0].first;
        min_lat = max_lat = coords[0].second;
        for (const auto& coord : coords) {
            min_lon = std::min(min_lon, coord.first);
            max_lon = std::max(max_lon, coord.first);
            min_lat = std::min(min_lat, coord.second);
            max_lat = std::max(max_lat, coord.second);
        }
        
        Point start(coords[0].first, coords[0].second);
        Point end(coords.back().first, coords.back().second);
        direction = calculate_bearing(start, end);
    }
    
    length = 0.0;
    for (size_t i = 0; i < coords.size() - 1; ++i) {
        Point p1(coords[i].first, coords[i].second);
        Point p2(coords[i+1].first, coords[i+1].second);
        length += haversine_distance(p1, p2);
    }
}

Edge create_reverse_edge(const Edge& original) {
    Edge reversed;
    reversed.id = original.id + "_rev";
    reversed.source = original.target;
    reversed.target = original.source;
    reversed.coords = original.coords;
    std::reverse(reversed.coords.begin(), reversed.coords.end());
    reversed.speed_limit = original.speed_limit;
    reversed.two_way = original.two_way;
    
    if (reversed.coords.size() >= 2) {
        reversed.min_lon = reversed.max_lon = reversed.coords[0].first;
        reversed.min_lat = reversed.max_lat = reversed.coords[0].second;
        for (const auto& coord : reversed.coords) {
            reversed.min_lon = std::min(reversed.min_lon, coord.first);
            reversed.max_lon = std::max(reversed.max_lon, coord.first);
            reversed.min_lat = std::min(reversed.min_lat, coord.second);
            reversed.max_lat = std::max(reversed.max_lat, coord.second);
        }
        
        Point start(reversed.coords[0].first, reversed.coords[0].second);
        Point end(reversed.coords.back().first, reversed.coords.back().second);
        reversed.direction = calculate_bearing(start, end);
    }
    
    reversed.length = original.length;
    return reversed;
}

HMMMapMatching::HMMMapMatching(const std::vector<Edge>& edges) {
    for (const auto& edge : edges) {
        this->edges.push_back(edge);
        edge_id_map[edge.id] = edge;
        
        if (edge.two_way) {
            Edge reversed = create_reverse_edge(edge);
            this->edges.push_back(reversed);
            edge_id_map[reversed.id] = reversed;
        }
    }
    
    for (const auto& edge : this->edges) {
        int min_x = static_cast<int>(std::floor(edge.min_lon / LON_INTERVAL));
        int max_x = static_cast<int>(std::floor(edge.max_lon / LON_INTERVAL));
        int min_y = static_cast<int>(std::floor(edge.min_lat / LAT_INTERVAL));
        int max_y = static_cast<int>(std::floor(edge.max_lat / LAT_INTERVAL));
        
        for (int x = min_x; x <= max_x; ++x) {
            for (int y = min_y; y <= max_y; ++y) {
                grid[std::make_pair(x, y)].push_back(edge);
            }
        }
    }
    
    for (const auto& edge : this->edges) {
        adj_list[edge.source].push_back({edge.target, edge.id, edge.length, edge.speed_limit});
    }
}

std::vector<Edge> HMMMapMatching::get_candidate_edges(double lon, double lat, int expand) const {
    int grid_x = static_cast<int>(std::floor(lon / LON_INTERVAL));
    int grid_y = static_cast<int>(std::floor(lat / LAT_INTERVAL));
    
    std::vector<Edge> candidates;
    std::unordered_set<std::string> seen;
    
    for (int dx = -expand; dx <= expand; ++dx) {
        for (int dy = -expand; dy <= expand; ++dy) {
            auto key = std::make_pair(grid_x + dx, grid_y + dy);
            auto it = grid.find(key);
            if (it != grid.end()) {
                for (const auto& edge : it->second) {
                    if (seen.find(edge.id) == seen.end()) {
                        seen.insert(edge.id);
                        candidates.push_back(edge);
                    }
                }
            }
        }
    }
    
    return candidates;
}

std::unordered_map<std::string, DijkstraResult> HMMMapMatching::dijkstra(const std::string& source, double max_dist) const {
    auto cache_it = dijkstra_cache.find(source);
    if (cache_it != dijkstra_cache.end()) {
        return cache_it->second;
    }
    
    std::unordered_map<std::string, DijkstraResult> results;
    std::priority_queue<std::tuple<double, double, std::string>,
                        std::vector<std::tuple<double, double, std::string>>,
                        std::greater<>> pq;
    
    pq.push({0.0, 0.0, source});
    results[source] = {0.0, 0.0};
    
    while (!pq.empty()) {
        auto [curr_dist, curr_time, u] = pq.top();
        pq.pop();
        
        if (max_dist > 0 && curr_dist > max_dist) continue;
        
        auto result_it = results.find(u);
        if (result_it != results.end() && curr_dist > result_it->second.distance) continue;
        
        auto adj_it = adj_list.find(u);
        if (adj_it == adj_list.end()) continue;
        
        for (const auto& neighbor : adj_it->second) {
            double alt_dist = curr_dist + neighbor.length;
            double alt_time = curr_time + neighbor.length / neighbor.speed_limit;
            
            auto existing_it = results.find(neighbor.target);
            if (existing_it == results.end() || alt_dist < existing_it->second.distance) {
                results[neighbor.target] = {alt_dist, alt_time};
                pq.push({alt_dist, alt_time, neighbor.target});
            }
        }
    }
    
    dijkstra_cache[source] = results;
    return results;
}

std::vector<Candidate> HMMMapMatching::generate_candidates(const Point& gps_point,
                                                           double radius,
                                                           const std::optional<double>& prev_bearing,
                                                           const std::optional<std::string>& prev_edge_id) const {
    std::vector<Candidate> candidates;
    candidates.reserve(32);
    
    Candidate nearest_cand;
    double nearest_dist = std::numeric_limits<double>::infinity();
    
    auto candidate_edges = get_candidate_edges(gps_point.lon, gps_point.lat);
    
    for (const auto& edge : candidate_edges) {
        double min_dist = std::numeric_limits<double>::infinity();
        Point best_proj(gps_point.lon, gps_point.lat);
        double best_offset = 0.0;
        double best_dir_diff = 0.0;
        
        for (size_t i = 0; i < edge.coords.size() - 1; ++i) {
            auto result = point_to_segment_distance(gps_point, edge.coords[i], edge.coords[i+1]);
            if (result.distance < min_dist) {
                min_dist = result.distance;
                best_proj = result.proj_point;
                best_offset = result.offset;
                
                if (prev_bearing) {
                    Point seg_start(edge.coords[i].first, edge.coords[i].second);
                    Point seg_end(edge.coords[i+1].first, edge.coords[i+1].second);
                    double seg_bearing = calculate_bearing(seg_start, seg_end);
                    double dir_diff = std::abs(*prev_bearing - seg_bearing);
                    if (dir_diff > PI) dir_diff = 2.0 * PI - dir_diff;
                    best_dir_diff = dir_diff;
                }
            }
        }
        
        if (min_dist < nearest_dist) {
            nearest_dist = min_dist;
            nearest_cand = Candidate(edge, best_offset, min_dist, best_proj, best_dir_diff, 0);
        }
        
        if (min_dist <= radius) {
            int continuity = (prev_edge_id && edge.id == *prev_edge_id) ? 1 : 0;
            candidates.push_back(Candidate(edge, best_offset, min_dist, best_proj, best_dir_diff, continuity));
        }
    }
    
    if (candidates.empty() && nearest_dist != std::numeric_limits<double>::infinity()) {
        candidates.push_back(nearest_cand);
    }
    
    std::sort(candidates.begin(), candidates.end(),
              [](const Candidate& a, const Candidate& b) {
                  double score_a = a.distance + 0.3 * a.direction_diff * 100.0 + (1.0 - a.edge_continuity) * 100.0;
                  double score_b = b.distance + 0.3 * b.direction_diff * 100.0 + (1.0 - b.edge_continuity) * 100.0;
                  return score_a < score_b;
              });
    
    return candidates;
}

double HMMMapMatching::observation_probability(double distance, double gps_error) const {
    double sigma = gps_error;
    return -distance * distance / (2.0 * sigma * sigma) - std::log(sigma * std::sqrt(2.0 * PI));
}

double HMMMapMatching::transition_probability(double sp_dist, double time_interval, double speed_limit) const {
    if (time_interval <= 0) time_interval = 1.0;
    
    double expected_dist = speed_limit * time_interval;
    if (expected_dist <= 0) expected_dist = 1.0;
    
    double beta = expected_dist / 2.0;
    if (sp_dist <= 0) sp_dist = 1e-10;
    
    double prob = -sp_dist / beta - std::log(beta);
    
    double max_reasonable_dist = speed_limit * time_interval * 3.0;
    if (sp_dist > max_reasonable_dist) {
        prob -= std::log(sp_dist / max_reasonable_dist) * 5.0;
    }
    
    return prob;
}

std::pair<double, double> HMMMapMatching::get_sp_distance(const Candidate& cand_a, const Candidate& cand_b) const {
    const Edge& edge_a = cand_a.edge;
    const Edge& edge_b = cand_b.edge;
    
    if (edge_a.id == edge_b.id) {
        double sp_dist = std::abs(cand_a.offset - cand_b.offset);
        double sp_time = sp_dist / edge_a.speed_limit;
        return {sp_dist, sp_time};
    }
    
    double ratio_a = (edge_a.length > 0) ? cand_a.offset / edge_a.length : 0.5;
    double ratio_b = (edge_b.length > 0) ? cand_b.offset / edge_b.length : 0.5;
    
    std::string node_a = (ratio_a < 0.5) ? edge_a.source : edge_a.target;
    std::string node_b = (ratio_b < 0.5) ? edge_b.source : edge_b.target;
    
    double dist_a = (node_a == edge_a.source) ? cand_a.offset : edge_a.length - cand_a.offset;
    double dist_b = (node_b == edge_b.source) ? cand_b.offset : edge_b.length - cand_b.offset;
    
    if (edge_a.target == edge_b.source || edge_a.target == edge_b.target ||
        edge_a.source == edge_b.source || edge_a.source == edge_b.target) {
        double sp_dist = dist_a + dist_b;
        double avg_speed = (edge_a.speed_limit + edge_b.speed_limit) / 2.0;
        double sp_time = sp_dist / avg_speed;
        return {sp_dist, sp_time};
    }
    
    auto dijkstra_results = dijkstra(node_a);
    auto it = dijkstra_results.find(node_b);
    if (it != dijkstra_results.end()) {
        double sp_dist = dist_a + it->second.distance + dist_b;
        double sp_time = it->second.time + dist_a / edge_a.speed_limit + dist_b / edge_b.speed_limit;
        return {sp_dist, sp_time};
    }
    
    double line_dist = haversine_distance(cand_a.point, cand_b.point) * 100.0;
    return {line_dist, line_dist / 30.0};
}

std::vector<Candidate> HMMMapMatching::match(const std::vector<Point>& trajectory,
                                             const std::vector<Point>* prior_trajectory,
                                             int k, double radius, double gps_error) {
    last_timing = Timing();
    dijkstra_cache.clear();
    
    if (trajectory.empty()) return {};
    
    auto start_time = std::chrono::high_resolution_clock::now();
    
    std::vector<double> bearings;
    for (size_t i = 1; i < trajectory.size(); ++i) {
        bearings.push_back(calculate_bearing(trajectory[i-1], trajectory[i]));
    }
    bearings.push_back(0.0);
    
    std::vector<double> time_intervals;
    for (size_t i = 1; i < trajectory.size(); ++i) {
        if (trajectory[i].timestamp > 0 && trajectory[i-1].timestamp > 0) {
            time_intervals.push_back(std::max((trajectory[i].timestamp - trajectory[i-1].timestamp) / 1000.0, 0.1));
        } else {
            time_intervals.push_back(1.0);
        }
    }
    
    std::optional<std::string> prev_edge_id;
    std::optional<double> initial_bearing;
    
    if (prior_trajectory && !prior_trajectory->empty()) {
        auto prior_result = match_core(*prior_trajectory, k, radius, gps_error);
        if (!prior_result.empty()) {
            prev_edge_id = prior_result.back().edge.id;
            if (prior_result.size() >= 2) {
                initial_bearing = calculate_bearing(prior_result[prior_result.size()-2].point,
                                                    prior_result.back().point);
            }
        }
    }
    
    std::vector<std::vector<Candidate>> candidate_layers;
    for (size_t i = 0; i < trajectory.size(); ++i) {
        std::optional<double> prev_bearing;
        if (i > 0) prev_bearing = bearings[i-1];
        else if (initial_bearing) prev_bearing = initial_bearing;
        
        auto candidates = generate_candidates(trajectory[i], radius, prev_bearing, prev_edge_id);
        if (candidates.size() > static_cast<size_t>(k)) {
            candidates.resize(k);
        }
        
        if (!candidates.empty()) {
            prev_edge_id = candidates[0].edge.id;
        }
        
        for (auto& cand : candidates) {
            cand.obs_prob = observation_probability(cand.distance, gps_error);
        }
        
        candidate_layers.push_back(candidates);
    }
    
    auto cand_gen_end = std::chrono::high_resolution_clock::now();
    last_timing.cand_gen = std::chrono::duration<double>(cand_gen_end - start_time).count();
    
    if (candidate_layers.empty() || candidate_layers[0].empty()) return {};
    
    std::vector<std::vector<Candidate>> layers = candidate_layers;
    
    for (auto& cand : layers[0]) {
        cand.path_prob = cand.obs_prob;
        cand.prev_index = -1;
    }
    
    for (size_t i = 1; i < layers.size(); ++i) {
        auto& curr_layer = layers[i];
        auto& prev_layer = layers[i-1];
        
        if (prev_layer.empty()) continue;
        
        if (curr_layer.empty()) {
            auto best_prev = std::max_element(prev_layer.begin(), prev_layer.end(),
                                              [](const Candidate& a, const Candidate& b) {
                                                  return a.path_prob < b.path_prob;
                                              });
            Candidate new_cand = *best_prev;
            new_cand.obs_prob = -100.0;
            new_cand.path_prob = best_prev->path_prob + new_cand.obs_prob;
            new_cand.prev_index = static_cast<int>(std::distance(prev_layer.begin(), best_prev));
            curr_layer.push_back(new_cand);
            continue;
        }
        
        double time_interval = (i-1 < time_intervals.size()) ? time_intervals[i-1] : 1.0;
        std::optional<double> gps_bearing;
        if (i-1 < bearings.size()) gps_bearing = bearings[i-1];
        
        for (size_t j = 0; j < curr_layer.size(); ++j) {
            auto& curr_cand = curr_layer[j];
            double max_prob = -std::numeric_limits<double>::infinity();
            int best_prev_idx = -1;
            
            for (size_t k_idx = 0; k_idx < prev_layer.size(); ++k_idx) {
                const auto& prev_cand = prev_layer[k_idx];
                
                auto [sp_dist, sp_time] = get_sp_distance(prev_cand, curr_cand);
                double avg_speed = (prev_cand.edge.speed_limit + curr_cand.edge.speed_limit) / 2.0;
                double trans_prob = transition_probability(sp_dist, time_interval, avg_speed);
                
                double continuity_bonus = 0.0;
                if (prev_cand.edge.id == curr_cand.edge.id) {
                    continuity_bonus = 5.5;
                } else {
                    const Edge& edge_a = prev_cand.edge;
                    const Edge& edge_b = curr_cand.edge;
                    if (edge_a.target == edge_b.source || edge_a.source == edge_b.target ||
                        edge_a.target == edge_b.target || edge_a.source == edge_b.source) {
                        continuity_bonus = 3.0;
                    }
                }
                
                double speed_bonus = 0.0;
                double max_reasonable_dist = avg_speed * time_interval;
                if (sp_dist <= max_reasonable_dist) {
                    speed_bonus = 1.0;
                }
                
                double direction_bonus = 0.0;
                if (gps_bearing) {
                    double cand_direction = calculate_bearing(prev_cand.point, curr_cand.point);
                    double angle_diff = std::abs(*gps_bearing - cand_direction);
                    if (angle_diff > PI) angle_diff = 2.0 * PI - angle_diff;
                    if (angle_diff < PI / 2.0) {
                        direction_bonus = 2.0;
                    }
                }
                
                double total_prob = prev_cand.path_prob + trans_prob + curr_cand.obs_prob +
                                    continuity_bonus + speed_bonus + direction_bonus;
                
                if (total_prob > max_prob) {
                    max_prob = total_prob;
                    best_prev_idx = static_cast<int>(k_idx);
                }
            }
            
            if (best_prev_idx == -1 && !prev_layer.empty()) {
                best_prev_idx = 0;
                max_prob = prev_layer[0].path_prob + curr_cand.obs_prob;
            }
            
            curr_cand.path_prob = max_prob;
            curr_cand.prev_index = best_prev_idx;
        }
    }
    
    auto viterbi_end = std::chrono::high_resolution_clock::now();
    last_timing.viterbi = std::chrono::duration<double>(viterbi_end - cand_gen_end).count();
    
    if (layers.empty() || layers.back().empty()) return {};
    
    auto best_last = std::max_element(layers.back().begin(), layers.back().end(),
                                      [](const Candidate& a, const Candidate& b) {
                                          return a.path_prob < b.path_prob;
                                      });
    
    std::vector<Candidate> result;
    int curr_layer_idx = static_cast<int>(layers.size()) - 1;
    int curr_cand_idx = static_cast<int>(std::distance(layers.back().begin(), best_last));
    
    while (curr_layer_idx >= 0) {
        result.push_back(layers[curr_layer_idx][curr_cand_idx]);
        curr_cand_idx = layers[curr_layer_idx][curr_cand_idx].prev_index;
        curr_layer_idx--;
    }
    
    std::reverse(result.begin(), result.end());
    
    auto backtrack_end = std::chrono::high_resolution_clock::now();
    last_timing.backtrack = std::chrono::duration<double>(backtrack_end - viterbi_end).count();
    last_timing.total = std::chrono::duration<double>(backtrack_end - start_time).count();
    
    return result;
}

std::vector<Candidate> HMMMapMatching::match_core(const std::vector<Point>& trajectory,
                                                  int k, double radius, double gps_error) {
    if (trajectory.empty()) return {};
    
    std::vector<double> bearings;
    for (size_t i = 1; i < trajectory.size(); ++i) {
        bearings.push_back(calculate_bearing(trajectory[i-1], trajectory[i]));
    }
    bearings.push_back(0.0);
    
    std::vector<double> time_intervals;
    for (size_t i = 1; i < trajectory.size(); ++i) {
        if (trajectory[i].timestamp > 0 && trajectory[i-1].timestamp > 0) {
            time_intervals.push_back(std::max((trajectory[i].timestamp - trajectory[i-1].timestamp) / 1000.0, 0.1));
        } else {
            time_intervals.push_back(1.0);
        }
    }
    
    std::optional<std::string> prev_edge_id;
    std::vector<std::vector<Candidate>> candidate_layers;
    
    for (size_t i = 0; i < trajectory.size(); ++i) {
        std::optional<double> prev_bearing;
        if (i > 0) prev_bearing = bearings[i-1];
        
        auto candidates = generate_candidates(trajectory[i], radius, prev_bearing, prev_edge_id);
        if (candidates.size() > static_cast<size_t>(k)) {
            candidates.resize(k);
        }
        
        if (!candidates.empty()) {
            prev_edge_id = candidates[0].edge.id;
        }
        
        for (auto& cand : candidates) {
            cand.obs_prob = observation_probability(cand.distance, gps_error);
        }
        
        candidate_layers.push_back(candidates);
    }
    
    if (candidate_layers.empty() || candidate_layers[0].empty()) return {};
    
    std::vector<std::vector<Candidate>> layers = candidate_layers;
    
    for (auto& cand : layers[0]) {
        cand.path_prob = cand.obs_prob;
        cand.prev_index = -1;
    }
    
    for (size_t i = 1; i < layers.size(); ++i) {
        auto& curr_layer = layers[i];
        auto& prev_layer = layers[i-1];
        
        if (prev_layer.empty()) continue;
        
        if (curr_layer.empty()) {
            auto best_prev = std::max_element(prev_layer.begin(), prev_layer.end(),
                                              [](const Candidate& a, const Candidate& b) {
                                                  return a.path_prob < b.path_prob;
                                              });
            Candidate new_cand = *best_prev;
            new_cand.obs_prob = -100.0;
            new_cand.path_prob = best_prev->path_prob + new_cand.obs_prob;
            new_cand.prev_index = static_cast<int>(std::distance(prev_layer.begin(), best_prev));
            curr_layer.push_back(new_cand);
            continue;
        }
        
        double time_interval = (i-1 < time_intervals.size()) ? time_intervals[i-1] : 1.0;
        std::optional<double> gps_bearing;
        if (i-1 < bearings.size()) gps_bearing = bearings[i-1];
        
        for (size_t j = 0; j < curr_layer.size(); ++j) {
            auto& curr_cand = curr_layer[j];
            double max_prob = -std::numeric_limits<double>::infinity();
            int best_prev_idx = -1;
            
            for (size_t k_idx = 0; k_idx < prev_layer.size(); ++k_idx) {
                const auto& prev_cand = prev_layer[k_idx];
                auto [sp_dist, sp_time] = get_sp_distance(prev_cand, curr_cand);
                double avg_speed = (prev_cand.edge.speed_limit + curr_cand.edge.speed_limit) / 2.0;
                double trans_prob = transition_probability(sp_dist, time_interval, avg_speed);
                
                double continuity_bonus = 0.0;
                if (prev_cand.edge.id == curr_cand.edge.id) {
                    continuity_bonus = 5.5;
                } else {
                    const Edge& edge_a = prev_cand.edge;
                    const Edge& edge_b = curr_cand.edge;
                    if (edge_a.target == edge_b.source || edge_a.source == edge_b.target ||
                        edge_a.target == edge_b.target || edge_a.source == edge_b.source) {
                        continuity_bonus = 3.0;
                    }
                }
                
                double speed_bonus = 0.0;
                double max_reasonable_dist = avg_speed * time_interval;
                if (sp_dist <= max_reasonable_dist) {
                    speed_bonus = 1.0;
                }
                
                double direction_bonus = 0.0;
                if (gps_bearing) {
                    double cand_direction = calculate_bearing(prev_cand.point, curr_cand.point);
                    double angle_diff = std::abs(*gps_bearing - cand_direction);
                    if (angle_diff > PI) angle_diff = 2.0 * PI - angle_diff;
                    if (angle_diff < PI / 2.0) {
                        direction_bonus = 2.0;
                    }
                }
                
                double total_prob = prev_cand.path_prob + trans_prob + curr_cand.obs_prob +
                                    continuity_bonus + speed_bonus + direction_bonus;
                
                if (total_prob > max_prob) {
                    max_prob = total_prob;
                    best_prev_idx = static_cast<int>(k_idx);
                }
            }
            
            if (best_prev_idx == -1 && !prev_layer.empty()) {
                best_prev_idx = 0;
                max_prob = prev_layer[0].path_prob + curr_cand.obs_prob;
            }
            
            curr_cand.path_prob = max_prob;
            curr_cand.prev_index = best_prev_idx;
        }
    }
    
    if (layers.empty() || layers.back().empty()) return {};
    
    auto best_last = std::max_element(layers.back().begin(), layers.back().end(),
                                      [](const Candidate& a, const Candidate& b) {
                                          return a.path_prob < b.path_prob;
                                      });
    
    std::vector<Candidate> result;
    int curr_layer_idx = static_cast<int>(layers.size()) - 1;
    int curr_cand_idx = static_cast<int>(std::distance(layers.back().begin(), best_last));
    
    while (curr_layer_idx >= 0) {
        result.push_back(layers[curr_layer_idx][curr_cand_idx]);
        curr_cand_idx = layers[curr_layer_idx][curr_cand_idx].prev_index;
        curr_layer_idx--;
    }
    
    std::reverse(result.begin(), result.end());
    
    return result;
}

@echo off
setlocal enabledelayedexpansion

echo ========================================
echo HMM Map Matching - C++ Version
echo ========================================
echo.

REM Try to find and set up Visual Studio environment
set "VS_FOUND=0"

REM Check for VS in D:\Tools\VSC
if exist "D:\Tools\VSC\VC\Auxiliary\Build\vcvarsall.bat" (
    call "D:\Tools\VSC\VC\Auxiliary\Build\vcvarsall.bat" x64
    set "VS_FOUND=1"
)

REM Check for Visual Studio 2022
if "%VS_FOUND%"=="0" (
    if exist "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files\Microsoft Visual Studio\2022\Community\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    ) else if exist "C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files\Microsoft Visual Studio\2022\Professional\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    ) else if exist "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    )
)

REM Check for Visual Studio 2019
if "%VS_FOUND%"=="0" (
    if exist "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files (x86)\Microsoft Visual Studio\2019\Community\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    ) else if exist "C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files (x86)\Microsoft Visual Studio\2019\Professional\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    ) else if exist "C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files (x86)\Microsoft Visual Studio\2019\Enterprise\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    )
)

REM Check for Visual Studio 2017
if "%VS_FOUND%"=="0" (
    if exist "C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files (x86)\Microsoft Visual Studio\2017\Community\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    ) else if exist "C:\Program Files (x86)\Microsoft Visual Studio\2017\Professional\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files (x86)\Microsoft Visual Studio\2017\Professional\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    ) else if exist "C:\Program Files (x86)\Microsoft Visual Studio\2017\Enterprise\Common7\Tools\VsDevCmd.bat" (
        call "C:\Program Files (x86)\Microsoft Visual Studio\2017\Enterprise\Common7\Tools\VsDevCmd.bat"
        set "VS_FOUND=1"
    )
)

if "%VS_FOUND%"=="0" (
    echo Error: Visual Studio not found.
    echo Please install Visual Studio or run from Visual Studio Developer Command Prompt.
    echo.
    pause
    exit /b 1
)

echo [1/3] Compiling C++ code...
cl /std:c++17 /EHsc /utf-8 /O2 /arch:AVX2 /GL main.cpp hmm_map_matching.cpp /Fe:hmm_map_matching.exe
if %ERRORLEVEL% NEQ 0 (
    echo Compilation failed!
    pause
    exit /b 1
)

echo Compilation successful!
echo.

echo [2/3] Running map matching (without prior)...
hmm_map_matching.exe --truth ..\input\data_utf8.csv --output ..\output\output_without_prior.csv
echo.

echo [3/3] Running map matching (with 1-minute prior)...
hmm_map_matching.exe --truth ..\input\data_utf8.csv --prior 1 --output ..\output\output_with_prior.csv
echo.

echo ========================================
echo All tasks completed!
echo ========================================
pause

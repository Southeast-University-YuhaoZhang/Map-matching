#ifndef HMM_MAP_MATCHING_H
#define HMM_MAP_MATCHING_H

#include <vector>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <tuple>
#include <optional>
#include <chrono>
#include <map>
#include <cmath>

const double PI = 3.14159265358979323846;

inline double to_radians(double degrees) {
    return degrees * PI / 180.0;
}

struct Point {
    double lon;
    double lat;
    long long timestamp;

    Point() : lon(0.0), lat(0.0), timestamp(0) {}
    Point(double lon, double lat) : lon(lon), lat(lat), timestamp(0) {}
    Point(double lon, double lat, long long timestamp) : lon(lon), lat(lat), timestamp(timestamp) {}
};

struct PointToSegmentResult {
    double distance;
    Point proj_point;
    double offset;

    PointToSegmentResult() : distance(0.0), offset(0.0) {}
};

struct Edge {
    std::string id;
    std::string source;
    std::string target;
    std::vector<std::pair<double, double>> coords;
    double speed_limit;
    bool two_way;
    double length;
    double min_lon;
    double max_lon;
    double min_lat;
    double max_lat;
    double direction;

    Edge() : speed_limit(22.22), two_way(true), length(0.0),
             min_lon(0.0), max_lon(0.0), min_lat(0.0), max_lat(0.0), direction(0.0) {}

    Edge(const std::string& edge_id, const std::string& source, const std::string& target,
         const std::vector<std::pair<double, double>>& coords, double speed_limit, bool two_way);
};

struct Candidate {
    Edge edge;
    double offset;
    double distance;
    Point point;
    double direction_diff;
    int edge_continuity;
    double obs_prob;
    double path_prob;
    int prev_index;

    Candidate() : offset(0.0), distance(0.0), direction_diff(0.0),
                  edge_continuity(0), obs_prob(0.0), path_prob(-1e300), prev_index(-1) {}

    Candidate(const Edge& edge, double offset, double distance, const Point& point,
              double direction_diff, int edge_continuity)
        : edge(edge), offset(offset), distance(distance), point(point),
          direction_diff(direction_diff), edge_continuity(edge_continuity),
          obs_prob(0.0), path_prob(-1e300), prev_index(-1) {}
};

struct AdjacencyInfo {
    std::string target;
    std::string edge_id;
    double length;
    double speed_limit;

    AdjacencyInfo() : length(0.0), speed_limit(0.0) {}
    AdjacencyInfo(const std::string& target, const std::string& edge_id, double length, double speed_limit)
        : target(target), edge_id(edge_id), length(length), speed_limit(speed_limit) {}
};

struct DijkstraResult {
    double distance;
    double time;

    DijkstraResult() : distance(0.0), time(0.0) {}
    DijkstraResult(double distance, double time) : distance(distance), time(time) {}
};

struct Timing {
    double cand_gen;
    double viterbi;
    double backtrack;
    double total;

    Timing() : cand_gen(0.0), viterbi(0.0), backtrack(0.0), total(0.0) {}
};

std::string create_node_id(double lon, double lat, int precision = 6);
double haversine_distance(const Point& p1, const Point& p2);
double calculate_bearing(const Point& p1, const Point& p2);
PointToSegmentResult point_to_segment_distance(const Point& point,
                                               const std::pair<double, double>& seg_start,
                                               const std::pair<double, double>& seg_end);

class HMMMapMatching {
public:
    explicit HMMMapMatching(const std::vector<Edge>& edges);

    std::vector<Candidate> match(const std::vector<Point>& trajectory,
                                 const std::vector<Point>* prior_trajectory = nullptr,
                                 int k = 8, double radius = 100.0, double gps_error = 15.0);

    Timing get_last_timing() const { return last_timing; }

private:
    std::vector<Edge> edges;
    std::unordered_map<std::string, Edge> edge_id_map;
    std::map<std::pair<int, int>, std::vector<Edge>> grid;
    std::unordered_map<std::string, std::vector<AdjacencyInfo>> adj_list;
    mutable std::unordered_map<std::string, std::unordered_map<std::string, DijkstraResult>> dijkstra_cache;
    Timing last_timing;

    std::vector<Edge> get_candidate_edges(double lon, double lat, int expand = 2) const;
    std::unordered_map<std::string, DijkstraResult> dijkstra(const std::string& source, double max_dist = 2000.0) const;
    std::vector<Candidate> generate_candidates(const Point& gps_point,
                                               double radius,
                                               const std::optional<double>& prev_bearing,
                                               const std::optional<std::string>& prev_edge_id) const;
    double observation_probability(double distance, double gps_error) const;
    double transition_probability(double sp_dist, double time_interval, double speed_limit) const;
    std::pair<double, double> get_sp_distance(const Candidate& cand_a, const Candidate& cand_b) const;
    std::vector<Candidate> match_core(const std::vector<Point>& trajectory,
                                      int k, double radius, double gps_error);
};

#endif // HMM_MAP_MATCHING_H
